#include <iostream>
#include <vector>
#include <sstream>

using namespace std;

class Stock {
public:
    Stock(const string& name, double price) : name(name), price(price), quantity(0) {}

    string getName() const { return name; }
    double getPrice() const { return price; }

private:
    string name;
    double price;
    int quantity;
};

class Account {
public:
    Account(double initialBalance);

    double getBalance() const;
    void deposit(double amount);
    void buyStock(const Stock& stock, int quantity);
    void sellStock(const Stock& stock, int quantity);

    void displayTransactions() const;

private:
    double balance;
    vector<string> transactionHistory;
};

Account::Account(double initialBalance) : balance(initialBalance) {}

double Account::getBalance() const {
    return balance;
}

void Account::deposit(double amount) {
    balance += amount;
    stringstream ss;
    ss << "Deposited $" << amount;
    transactionHistory.push_back(ss.str());
}

void Account::buyStock(const Stock& stock, int quantity) {
    double totalPrice = stock.getPrice() * quantity;
    if (totalPrice > balance) {
        cout << "Insufficient funds for buying stocks." << endl;
        return;
    }

    balance -= totalPrice;
    stringstream ss;
    ss << "Bought " << quantity << " shares of " << stock.getName() << " for $" << totalPrice;
    transactionHistory.push_back(ss.str());
}

void Account::sellStock(const Stock& stock, int quantity) {
    double totalPrice = stock.getPrice() * quantity;
    balance += totalPrice;
    stringstream ss;
    ss << "Sold " << quantity << " shares of " << stock.getName() << " for $" << totalPrice;
    transactionHistory.push_back(ss.str());
}

void Account::displayTransactions() const {
    cout << "Transaction History:" << endl;
    for (size_t i = 0; i < transactionHistory.size(); ++i) {
        cout << transactionHistory[i] << endl;
    }
}

int main() {
    const int MAX_STOCKS = 5;
    Stock stocks[MAX_STOCKS] = {
        Stock("Amazon", 150.0),
        Stock("Apple", 2500.0),
        Stock("Facebook", 3500.0),
        Stock("Micrsoft",7800.0),
        Stock("Tesla",6000.0),
        
    };

    Account userAccount(1000.0);

    int choice;
    do {
        cout << "1. Check Account Info\n"
             << "2. Deposit Money\n"
             << "3. Buy Stocks\n"
             << "4. Sell Stocks\n"
             << "5. Display Transaction History\n"
             << "6. Exit\n"
             << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Your Account Balance: $" << userAccount.getBalance() << endl;
                break;
            case 2:
                double depositAmount;
                cout << "Enter the deposit amount: ";
                cin >> depositAmount;
                

                if (depositAmount < 0) {
                    cout << "Invalid deposit amount. Please enter a positive value." << endl;
                    break;
                }

                userAccount.deposit(depositAmount);
                cout << "Amount deposited successfully." << endl;
                break;
            case 3:
                int stockIndex;
                cout << "Select a stock to buy:" << endl;
                for (int i = 0; i < MAX_STOCKS; ++i) {
                    cout << i + 1 << ". " << stocks[i].getName() << " ($" << stocks[i].getPrice() << ")" << endl;
                }
                cin >> stockIndex;
                if (stockIndex >= 1 && stockIndex <= MAX_STOCKS) {
                    int quantity;
                    cout << "Enter the quantity to buy: ";
                    cin >> quantity;
                    userAccount.buyStock(stocks[stockIndex - 1], quantity);
                    cout<<"Purchased Succesfully"<<endl;
                } else {
                    cout << "Invalid stock selection." << endl;
                }
                break;
            case 4:
                int sellStockIndex;
                cout << "Select a stock to sell:" << endl;
                for (int i = 0; i < MAX_STOCKS; ++i) {
                    cout << i + 1 << ". " << stocks[i].getName() << " ($" << stocks[i].getPrice() << ")" << endl;
                }
                cin >> sellStockIndex;
                if (sellStockIndex >= 1 && sellStockIndex <= MAX_STOCKS) {
                    int quantity;
                    cout << "Enter the quantity to sell: ";
                    cin >> quantity;
                    userAccount.sellStock(stocks[sellStockIndex - 1], quantity);
                    cout << "Sold stocks successfully." << endl;
                } else {
                    cout << "Invalid stock selection." << endl;
                }
                break;
            case 5:
                userAccount.displayTransactions();
                break;
            case 6:
                cout << "Exiting the application." << endl;
                break;
            default:
                cout << "Invalid choice. Please select a valid option." << endl;
        }
    } while (choice != 6);

    return 0;
}

